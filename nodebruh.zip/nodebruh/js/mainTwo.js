alert("Blue!")
